# Tathyoth frontend

Plain HTML, CSS and JavaScript. No build step, no dependencies, no remote assets.

## Run
    npx serve .        # or any static server; open the printed address

## Connect a backend
Edit `CONFIG.apiBase` at the top of `app.js` (e.g. `http://localhost:3000`) and allow this origin in the gateway's CORS list.
With `apiBase` empty the page runs in labelled demo mode: no verdicts are invented, and sample bounties and trending items say they are demo content.

## Endpoints used
`POST /api/query` `POST /api/feedback` `POST /api/challenges` `POST /api/sources` `GET /api/bounties` `GET /api/trending`.
Replies are validated in `clean()` before rendering. All text is inserted with text nodes, never `innerHTML`.

## Not yet built
Hindi/Hinglish translation of interface text, job polling for slow checks, sign-in, automated tests. See the project plan.
